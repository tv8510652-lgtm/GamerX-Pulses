import React, { useState, useMemo } from "react";
import {
  Platform,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from "react-native";
import * as Device from "expo-device";
import { LinearGradient } from "expo-linear-gradient";
import { MaterialCommunityIcons, Feather } from "@expo/vector-icons";
import {
  PROCESSORS,
  TIER_CONFIG,
  BRAND_CONFIG,
  type Processor,
  type ProcessorTier,
} from "@/constants/processors";
import AdBanner from "@/components/AdBanner";
import { useColors } from "@/hooks/useColors";

const GAMES = [
  { key: "pubg" as const, name: "PUBG Mobile", icon: "🎯" },
  { key: "genshin" as const, name: "Genshin Impact", icon: "⚔️" },
  { key: "cod" as const, name: "Call of Duty", icon: "🔫" },
];

function fpsColor(fps: number) {
  if (fps >= 90) return "#00ff88";
  if (fps >= 60) return "#00ccff";
  if (fps >= 40) return "#ffaa00";
  return "#ff6b6b";
}

function fpsLabel(fps: number) {
  if (fps >= 90) return "ممتاز";
  if (fps >= 60) return "جيد";
  if (fps >= 40) return "مقبول";
  return "ضعيف";
}

function getAiTier(ramBytes: number | null): {
  tier: string;
  tierEn: string;
  pubg: string;
  heavy: string;
  color: string;
} {
  const gb = ramBytes ? ramBytes / (1024 ** 3) : 0;
  const cores = 8;
  if (cores >= 8 && gb >= 8)
    return { tier: "رائد / خارق 🏆", tierEn: "High-End / Flagship", pubg: "90 – 120 FPS", heavy: "60 – 90 FPS", color: "#00ccff" };
  if (cores >= 6 && gb >= 4)
    return { tier: "متوسط ممتاز 🥈", tierEn: "Mid-Range", pubg: "60 FPS", heavy: "45 FPS", color: "#00ff88" };
  return { tier: "اقتصادي 🥉", tierEn: "Budget / Low-End", pubg: "30 FPS", heavy: "24 FPS", color: "#ffaa00" };
}

function ProcessorCard({ proc, onClose }: { proc: Processor; onClose: () => void }) {
  const tier = TIER_CONFIG[proc.tier];
  const brand = BRAND_CONFIG[proc.brand];

  return (
    <View style={[cardStyles.root, { borderColor: tier.color + "55" }]}>
      <LinearGradient colors={[tier.bg, "#0a0a0f00"]} style={cardStyles.grad}>
        {/* Top row */}
        <View style={cardStyles.topRow}>
          <View style={[cardStyles.brandBadge, { backgroundColor: brand.color + "22", borderColor: brand.color + "55" }]}>
            <Text style={[cardStyles.brandText, { color: brand.color }]}>{brand.short}</Text>
          </View>
          <Text style={[cardStyles.tierLabel, { color: tier.color }]}>{tier.labelEn}</Text>
          <View style={[cardStyles.tierBadgeAr, { backgroundColor: tier.bg, borderColor: tier.color + "44" }]}>
            <Text style={[cardStyles.tierBadgeText, { color: tier.color }]}>{tier.labelAr}</Text>
          </View>
          <TouchableOpacity onPress={onClose} style={cardStyles.closeBtn}>
            <Feather name="x" size={16} color="#6b7494" />
          </TouchableOpacity>
        </View>

        {/* Name */}
        <Text style={cardStyles.procName}>{proc.name}</Text>
        <Text style={cardStyles.procMeta}>
          {proc.brand} · {proc.architecture} · {proc.year} · {proc.cores} أنوية
        </Text>
        <Text style={cardStyles.procDesc}>{proc.description}</Text>

        {/* FPS grid */}
        <View style={cardStyles.fpsGrid}>
          {GAMES.map((g) => {
            const fps = proc.fps[g.key];
            const color = fpsColor(fps);
            return (
              <View key={g.key} style={[cardStyles.fpsCell, { borderColor: color + "44" }]}>
                <Text style={cardStyles.fpsGameIcon}>{g.icon}</Text>
                <Text style={cardStyles.fpsGameName}>{g.name}</Text>
                <Text style={[cardStyles.fpsValue, { color }]}>{fps}</Text>
                <Text style={cardStyles.fpsSuffix}>FPS</Text>
                <Text style={[cardStyles.fpsLbl, { color }]}>{fpsLabel(fps)}</Text>
              </View>
            );
          })}
        </View>

        {/* Score bar */}
        <View style={cardStyles.scoreRow}>
          <Text style={cardStyles.scoreLabel}>تقييم الجيمينج</Text>
          <View style={cardStyles.scoreTrack}>
            <View style={[cardStyles.scoreFill, {
              width: `${proc.gaming_score}%` as any,
              backgroundColor: tier.color,
            }]} />
          </View>
          <Text style={[cardStyles.scoreVal, { color: tier.color }]}>{proc.gaming_score}/100</Text>
        </View>
      </LinearGradient>
    </View>
  );
}

function AiFallback({ query }: { query: string }) {
  const totalRam = Device.totalMemory ?? null;
  const ai = getAiTier(totalRam);

  return (
    <View style={fbStyles.root}>
      <LinearGradient colors={["#ffaa0014", "#0a0a0f00"]} style={fbStyles.grad}>
        {/* AI badge */}
        <View style={fbStyles.badgeRow}>
          <MaterialCommunityIcons name="robot" size={18} color="#ffaa00" />
          <View style={fbStyles.badge}>
            <Text style={fbStyles.badgeText}>Processor auto-analyzed via hardware specs!</Text>
          </View>
        </View>
        <View style={fbStyles.badgeRowAr}>
          <Text style={fbStyles.badgeTextAr}>🤖 تحليل تلقائي ذكي بناءً على عتاد الجهاز</Text>
        </View>

        {query.length > 0 && (
          <Text style={fbStyles.notFound}>
            لم يُعثر على "{query}" في الموسوعة
          </Text>
        )}

        <Text style={fbStyles.desc}>
          بناءً على مواصفات هاتفك الحقيقية (الذاكرة وعدد الأنوية)، التصنيف المقدّر هو:
        </Text>

        <Text style={[fbStyles.tierMain, { color: ai.color }]}>{ai.tier}</Text>
        <Text style={fbStyles.tierEn}>{ai.tierEn}</Text>

        <View style={fbStyles.fpsRows}>
          {[
            { game: "PUBG Mobile 🎯", fps: ai.pubg },
            { game: "الألعاب الثقيلة ⚔️", fps: ai.heavy },
          ].map((r) => (
            <View key={r.game} style={fbStyles.fpsRow}>
              <Text style={fbStyles.fpsGame}>{r.game}</Text>
              <Text style={[fbStyles.fpsVal, { color: ai.color }]}>{r.fps}</Text>
            </View>
          ))}
        </View>

        <Text style={fbStyles.note}>
          * هذا تقدير ذكي. ابحث عن اسم معالجك للحصول على نتائج دقيقة.
        </Text>
      </LinearGradient>
    </View>
  );
}

type SortKey = "tier" | "fps" | "score" | "year";

export default function ProcessorsScreen() {
  const colors = useColors();
  const [query, setQuery] = useState("");
  const [selected, setSelected] = useState<Processor | null>(null);
  const [sortBy, setSortBy] = useState<SortKey>("score");
  const [filterTier, setFilterTier] = useState<ProcessorTier | "all">("all");

  const filtered = useMemo(() => {
    let list = PROCESSORS;
    if (query.trim()) {
      const q = query.toLowerCase();
      list = list.filter(
        (p) =>
          p.name.toLowerCase().includes(q) ||
          p.brand.toLowerCase().includes(q) ||
          p.description.includes(q)
      );
    }
    if (filterTier !== "all") {
      list = list.filter((p) => p.tier === filterTier);
    }
    return [...list].sort((a, b) => {
      if (sortBy === "fps") return b.fps.pubg - a.fps.pubg;
      if (sortBy === "score") return b.gaming_score - a.gaming_score;
      if (sortBy === "year") return b.year - a.year;
      const tierOrder: Record<ProcessorTier, number> = { flagship: 0, "high-end": 1, "mid-range": 2, budget: 3 };
      return tierOrder[a.tier] - tierOrder[b.tier];
    });
  }, [query, sortBy, filterTier]);

  const showFallback = query.trim().length > 0 && filtered.length === 0;

  const SORT_OPTIONS: { key: SortKey; label: string }[] = [
    { key: "score", label: "التقييم" },
    { key: "fps", label: "FPS" },
    { key: "tier", label: "الفئة" },
    { key: "year", label: "الأحدث" },
  ];

  const TIER_FILTERS: { key: ProcessorTier | "all"; label: string }[] = [
    { key: "all", label: "الكل" },
    { key: "flagship", label: "رائد" },
    { key: "high-end", label: "متقدم" },
    { key: "mid-range", label: "متوسط" },
    { key: "budget", label: "اقتصادي" },
  ];

  return (
    <View style={[styles.root, { backgroundColor: colors.background }]}>
      <ScrollView contentContainerStyle={styles.scroll} showsVerticalScrollIndicator={false}>

        {/* Header */}
        <LinearGradient colors={["#00ff8818", "#0a0a0f00"]} style={styles.header}>
          <Text style={styles.title}>موسوعة المعالجات</Text>
          <Text style={styles.subtitle}>PROCESSOR ENCYCLOPEDIA</Text>
          <Text style={styles.count}>{PROCESSORS.length} معالج في القاعدة</Text>
        </LinearGradient>

        {/* Search */}
        <View style={styles.searchWrap}>
          <Feather name="search" size={18} color="#6b7494" style={styles.searchIcon} />
          <TextInput
            style={styles.searchInput}
            placeholder="ابحث عن اسم المعالج... (Snapdragon, Dimensity, Apple...)"
            placeholderTextColor="#3a3a55"
            value={query}
            onChangeText={(t) => { setQuery(t); setSelected(null); }}
            textAlign={Platform.OS === "web" ? "left" : "right"}
            returnKeyType="search"
          />
          {query.length > 0 && (
            <TouchableOpacity onPress={() => { setQuery(""); setSelected(null); }}>
              <Feather name="x" size={16} color="#6b7494" />
            </TouchableOpacity>
          )}
        </View>

        {/* Sort controls */}
        <View style={styles.controlsRow}>
          <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{ gap: 6 }}>
            {SORT_OPTIONS.map((s) => (
              <TouchableOpacity
                key={s.key}
                onPress={() => setSortBy(s.key)}
                style={[styles.chip, sortBy === s.key && styles.chipActive]}
              >
                <Text style={[styles.chipText, sortBy === s.key && styles.chipTextActive]}>{s.label}</Text>
              </TouchableOpacity>
            ))}
          </ScrollView>
        </View>

        {/* Tier filter */}
        <View style={styles.controlsRow}>
          <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{ gap: 6 }}>
            {TIER_FILTERS.map((f) => {
              const cfg = f.key !== "all" ? TIER_CONFIG[f.key] : null;
              const isActive = filterTier === f.key;
              return (
                <TouchableOpacity
                  key={f.key}
                  onPress={() => setFilterTier(f.key)}
                  style={[
                    styles.chip,
                    isActive && { backgroundColor: cfg?.bg ?? "#00ccff18", borderColor: cfg?.color ?? "#00ccff" },
                  ]}
                >
                  <Text style={[styles.chipText, isActive && { color: cfg?.color ?? "#00ccff" }]}>{f.label}</Text>
                </TouchableOpacity>
              );
            })}
          </ScrollView>
        </View>

        {/* Selected detail */}
        {selected && <ProcessorCard proc={selected} onClose={() => setSelected(null)} />}

        {/* AI fallback */}
        {showFallback && <AiFallback query={query} />}

        {/* Processor list */}
        {!showFallback && filtered.map((proc) => {
          const tier = TIER_CONFIG[proc.tier];
          const brand = BRAND_CONFIG[proc.brand];
          const isSelected = selected?.id === proc.id;
          return (
            <TouchableOpacity
              key={proc.id}
              onPress={() => setSelected(isSelected ? null : proc)}
              activeOpacity={0.8}
            >
              <View style={[styles.procRow, isSelected && { borderColor: tier.color }]}>
                <View style={[styles.brandTag, { backgroundColor: brand.color + "22" }]}>
                  <Text style={[styles.brandTagText, { color: brand.color }]}>{brand.short}</Text>
                </View>
                <View style={styles.procInfo}>
                  <Text style={styles.procName}>{proc.name}</Text>
                  <Text style={styles.procMeta}>{proc.brand} · {proc.year} · {proc.architecture}</Text>
                </View>
                <View style={{ alignItems: "flex-end", gap: 4 }}>
                  <View style={[styles.tierPill, { backgroundColor: tier.bg, borderColor: tier.color + "55" }]}>
                    <Text style={[styles.tierPillText, { color: tier.color }]}>{tier.labelEn}</Text>
                  </View>
                  <Text style={[styles.pubgFps, { color: fpsColor(proc.fps.pubg) }]}>
                    PUBG {proc.fps.pubg} FPS
                  </Text>
                </View>
              </View>
            </TouchableOpacity>
          );
        })}

        {/* Empty (no query, no results) */}
        {!showFallback && filtered.length === 0 && query.trim() === "" && (
          <Text style={styles.empty}>لا توجد نتائج</Text>
        )}

        <View style={{ height: 110 }} />
      </ScrollView>

      <AdBanner />
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1 },
  scroll: { paddingHorizontal: 20, paddingTop: 58 },
  header: { alignItems: "center", paddingVertical: 22, marginBottom: 14, borderRadius: 16 },
  title: { color: "#fff", fontSize: 26, fontWeight: "bold" },
  subtitle: { color: "#00ff88", fontSize: 11, letterSpacing: 4, marginTop: 3, opacity: 0.8 },
  count: { color: "#6b7494", fontSize: 12, marginTop: 6 },

  searchWrap: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: "#12121c",
    borderWidth: 1,
    borderColor: "#1e1e30",
    borderRadius: 12,
    paddingHorizontal: 14,
    height: 48,
    marginBottom: 10,
    gap: 10,
  },
  searchIcon: { flexShrink: 0 },
  searchInput: { flex: 1, color: "#fff", fontSize: 14 },

  controlsRow: { marginBottom: 10 },
  chip: {
    paddingHorizontal: 14,
    paddingVertical: 7,
    borderRadius: 20,
    backgroundColor: "#12121c",
    borderWidth: 1,
    borderColor: "#1e1e30",
  },
  chipActive: { backgroundColor: "#00ccff18", borderColor: "#00ccff" },
  chipText: { color: "#6b7494", fontSize: 12, fontWeight: "500" },
  chipTextActive: { color: "#00ccff" },

  procRow: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: "#12121c",
    borderWidth: 1,
    borderColor: "#1e1e30",
    borderRadius: 12,
    padding: 12,
    marginBottom: 8,
    gap: 10,
  },
  brandTag: {
    width: 36,
    height: 36,
    borderRadius: 8,
    alignItems: "center",
    justifyContent: "center",
    flexShrink: 0,
  },
  brandTagText: { fontSize: 9, fontWeight: "bold" },
  procInfo: { flex: 1 },
  procName: { color: "#fff", fontSize: 14, fontWeight: "600" },
  procMeta: { color: "#6b7494", fontSize: 11, marginTop: 2 },
  tierPill: {
    borderWidth: 1,
    borderRadius: 6,
    paddingHorizontal: 7,
    paddingVertical: 2,
  },
  tierPillText: { fontSize: 10, fontWeight: "bold" },
  pubgFps: { fontSize: 11, fontWeight: "600" },

  empty: { color: "#6b7494", textAlign: "center", marginTop: 40, fontSize: 14 },
});

const cardStyles = StyleSheet.create({
  root: {
    borderWidth: 1,
    borderRadius: 16,
    overflow: "hidden",
    marginBottom: 14,
  },
  grad: { padding: 16 },
  topRow: { flexDirection: "row", alignItems: "center", gap: 8, marginBottom: 10 },
  brandBadge: {
    borderWidth: 1,
    borderRadius: 6,
    paddingHorizontal: 7,
    paddingVertical: 3,
  },
  brandText: { fontSize: 11, fontWeight: "bold" },
  tierLabel: { fontSize: 11, fontWeight: "bold", flex: 1 },
  tierBadgeAr: { borderWidth: 1, borderRadius: 6, paddingHorizontal: 7, paddingVertical: 3 },
  tierBadgeText: { fontSize: 11, fontWeight: "bold" },
  closeBtn: { padding: 4 },
  procName: { color: "#fff", fontSize: 20, fontWeight: "bold", marginBottom: 4 },
  procMeta: { color: "#6b7494", fontSize: 12, marginBottom: 6 },
  procDesc: { color: "#aaaacc", fontSize: 13, lineHeight: 19, marginBottom: 14 },

  fpsGrid: { flexDirection: "row", gap: 8, marginBottom: 14 },
  fpsCell: {
    flex: 1,
    alignItems: "center",
    backgroundColor: "#0a0a0f88",
    borderWidth: 1,
    borderRadius: 10,
    paddingVertical: 10,
    gap: 2,
  },
  fpsGameIcon: { fontSize: 18 },
  fpsGameName: { color: "#6b7494", fontSize: 9, textAlign: "center" },
  fpsValue: { fontSize: 22, fontWeight: "bold" },
  fpsSuffix: { color: "#6b7494", fontSize: 9 },
  fpsLbl: { fontSize: 10, fontWeight: "600" },

  scoreRow: { flexDirection: "row", alignItems: "center", gap: 10 },
  scoreLabel: { color: "#6b7494", fontSize: 12, width: 90 },
  scoreTrack: { flex: 1, height: 6, backgroundColor: "#1e1e30", borderRadius: 3, overflow: "hidden" },
  scoreFill: { height: "100%", borderRadius: 3 },
  scoreVal: { fontSize: 13, fontWeight: "bold", width: 52, textAlign: "right" },
});

const fbStyles = StyleSheet.create({
  root: {
    borderWidth: 1,
    borderColor: "#ffaa0055",
    borderRadius: 16,
    overflow: "hidden",
    marginBottom: 14,
  },
  grad: { padding: 18 },
  badgeRow: { flexDirection: "row", alignItems: "center", gap: 8, marginBottom: 6 },
  badge: {
    backgroundColor: "#ffaa0022",
    borderRadius: 6,
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderWidth: 1,
    borderColor: "#ffaa0066",
  },
  badgeText: { color: "#ffaa00", fontSize: 11, fontWeight: "bold" },
  badgeRowAr: { marginBottom: 10 },
  badgeTextAr: { color: "#ffaa00", fontSize: 13, fontWeight: "bold" },
  notFound: { color: "#ff6b6b", fontSize: 13, marginBottom: 10 },
  desc: { color: "#aaaacc", fontSize: 13, lineHeight: 20, marginBottom: 14 },
  tierMain: { fontSize: 22, fontWeight: "bold", marginBottom: 4 },
  tierEn: { color: "#6b7494", fontSize: 13, marginBottom: 14 },
  fpsRows: { gap: 10, marginBottom: 14 },
  fpsRow: { flexDirection: "row", justifyContent: "space-between", alignItems: "center" },
  fpsGame: { color: "#fff", fontSize: 14 },
  fpsVal: { fontSize: 16, fontWeight: "bold" },
  note: { color: "#6b7494", fontSize: 11, fontStyle: "italic" },
});
