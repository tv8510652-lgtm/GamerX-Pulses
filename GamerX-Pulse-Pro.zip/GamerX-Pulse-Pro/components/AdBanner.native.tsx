import React from "react";
import { View, StyleSheet } from "react-native";
import { BannerAd, BannerAdSize, MobileAds } from "react-native-google-mobile-ads";

const AD_UNIT_ID = "ca-app-pub-3940256099942544/6300978111";

export function initAds() {
  MobileAds()
    .initialize()
    .catch(() => {});
}

export default function AdBanner() {
  return (
    <View style={styles.container}>
      <BannerAd unitId={AD_UNIT_ID} size={BannerAdSize.ANCHORED_ADAPTIVE_BANNER} />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    alignItems: "center",
    justifyContent: "center",
    paddingVertical: 4,
    backgroundColor: "#050505",
  },
});
