export { default, initAds } from "./AdBanner.native";
