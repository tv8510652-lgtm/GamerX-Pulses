const colors = {
  light: {
    text: "#ffffff",
    tint: "#00ccff",

    background: "#0a0a0f",
    foreground: "#ffffff",

    card: "#12121c",
    cardForeground: "#ffffff",

    primary: "#00ccff",
    primaryForeground: "#000000",

    secondary: "#1a1a2e",
    secondaryForeground: "#ffffff",

    muted: "#1a1a2e",
    mutedForeground: "#6b7494",

    accent: "#ff1a4b",
    accentForeground: "#ffffff",

    destructive: "#ff1a4b",
    destructiveForeground: "#ffffff",

    border: "#1e1e30",
    input: "#1e1e30",

    success: "#00ff88",
    warning: "#ffaa00",
    cyan: "#00ccff",
    blue: "#0077ff",
    purple: "#7b2fff",
    neonGreen: "#39ff14",
  },

  radius: 12,
};

export default colors;
