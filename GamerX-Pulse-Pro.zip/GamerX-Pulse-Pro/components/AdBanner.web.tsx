import React from "react";
import { View, Text, StyleSheet } from "react-native";

export function initAds() {}

export default function AdBanner() {
  return (
    <View style={styles.placeholder}>
      <Text style={styles.text}>إعلان — GamerX Pulse Pro</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  placeholder: {
    height: 50,
    backgroundColor: "#0d0d18",
    alignItems: "center",
    justifyContent: "center",
    borderTopWidth: 1,
    borderTopColor: "#1e1e30",
  },
  text: {
    color: "#3a3a55",
    fontSize: 11,
    letterSpacing: 1,
  },
});
