import React, { useEffect, useState } from "react";
import {
  Dimensions,
  Platform,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from "react-native";
import Constants from "expo-constants";
import * as Device from "expo-device";
import { LinearGradient } from "expo-linear-gradient";
import { MaterialCommunityIcons } from "@expo/vector-icons";
import AdBanner from "@/components/AdBanner";
import { useColors } from "@/hooks/useColors";

const { width: SCR_W, height: SCR_H } = Dimensions.get("screen");

type SpecRow = {
  icon: keyof typeof MaterialCommunityIcons.glyphMap;
  iconColor: string;
  labelAr: string;
  labelEn: string;
  value: string;
  highlight?: boolean;
};

function bytesToGB(bytes: number | null): string {
  if (!bytes) return "غير متاح";
  return (bytes / (1024 ** 3)).toFixed(1) + " GB";
}

function getGamingReadiness(totalRamBytes: number | null): {
  label: string;
  labelEn: string;
  color: string;
} {
  if (!totalRamBytes) return { label: "غير محدد", labelEn: "Unknown", color: "#6b7494" };
  const gb = totalRamBytes / (1024 ** 3);
  if (gb >= 8) return { label: "ممتاز للألعاب ✅", labelEn: "Excellent for Gaming", color: "#00ff88" };
  if (gb >= 6) return { label: "جيد للألعاب 🟡", labelEn: "Good for Gaming", color: "#ffaa00" };
  if (gb >= 4) return { label: "مقبول للألعاب 🟠", labelEn: "Acceptable", color: "#ff7700" };
  return { label: "محدود للألعاب 🔴", labelEn: "Limited for Gaming", color: "#ff1a4b" };
}

export default function SpecsScreen() {
  const colors = useColors();
  const [simAvailRam, setSimAvailRam] = useState(0);

  useEffect(() => {
    const totalBytes = Device.totalMemory ?? 0;
    const usedFraction = 0.45 + Math.random() * 0.2;
    setSimAvailRam(totalBytes * (1 - usedFraction));
    const id = setInterval(() => {
      const frac = 0.40 + Math.random() * 0.25;
      setSimAvailRam(totalBytes * (1 - frac));
    }, 3000);
    return () => clearInterval(id);
  }, []);

  const totalRam = Device.totalMemory ?? null;
  const readiness = getGamingReadiness(totalRam);

  const manufacturer = Device.manufacturer ?? "غير متاح";
  const modelName = Device.modelName ?? "غير متاح";
  const osVersion = Device.osVersion ?? "غير متاح";
  const deviceType = Device.deviceType === Device.DeviceType.PHONE
    ? "هاتف ذكي 📱"
    : Device.deviceType === Device.DeviceType.TABLET
    ? "جهاز لوحي 📟"
    : "جهاز غير محدد";

  const expoSdk = Constants.expoConfig?.sdkVersion ?? Constants.manifest2?.runtimeVersion ?? "—";
  const appVersion = Constants.expoConfig?.version ?? "1.0.0";

  const specs: SpecRow[] = [
    {
      icon: "factory",
      iconColor: "#00ccff",
      labelAr: "الشركة المصنّعة",
      labelEn: "Manufacturer",
      value: manufacturer.toUpperCase(),
    },
    {
      icon: "cellphone",
      iconColor: "#00ccff",
      labelAr: "موديل الهاتف",
      labelEn: "Model Name",
      value: modelName,
      highlight: true,
    },
    {
      icon: "memory",
      iconColor: "#00ff88",
      labelAr: "الذاكرة العشوائية الإجمالية",
      labelEn: "Total RAM",
      value: bytesToGB(totalRam),
      highlight: true,
    },
    {
      icon: "memory",
      iconColor: "#ffaa00",
      labelAr: "الذاكرة المتاحة (تقريبي)",
      labelEn: "Available RAM (approx.)",
      value: bytesToGB(simAvailRam || null),
    },
    {
      icon: "chip",
      iconColor: "#7b2fff",
      labelAr: "نوع الجهاز",
      labelEn: "Device Type",
      value: deviceType,
    },
    {
      icon: "android",
      iconColor: "#00ff88",
      labelAr: "إصدار نظام التشغيل",
      labelEn: "OS Version",
      value: `${Platform.OS === "android" ? "Android" : Platform.OS === "ios" ? "iOS" : "Web"} ${osVersion}`,
    },
    {
      icon: "monitor",
      iconColor: "#00ccff",
      labelAr: "دقة الشاشة",
      labelEn: "Screen Resolution",
      value: `${Math.round(SCR_W)} × ${Math.round(SCR_H)} px`,
    },
    {
      icon: "application",
      iconColor: "#6b7494",
      labelAr: "إصدار التطبيق",
      labelEn: "App Version",
      value: `v${appVersion} (Expo SDK ${expoSdk})`,
    },
  ];

  return (
    <View style={[styles.root, { backgroundColor: colors.background }]}>
      <ScrollView contentContainerStyle={styles.scroll} showsVerticalScrollIndicator={false}>

        {/* Header */}
        <LinearGradient colors={["#7b2fff1a", "#0a0a0f00"]} style={styles.header}>
          <Text style={styles.title}>مواصفات الجهاز</Text>
          <Text style={styles.subtitle}>FULL DEVICE SPECS</Text>
        </LinearGradient>

        {/* Gaming readiness banner */}
        <View style={[styles.readinessBanner, { borderColor: readiness.color }]}>
          <MaterialCommunityIcons name="gamepad-variant" size={20} color={readiness.color} />
          <View style={{ flex: 1 }}>
            <Text style={[styles.readinessLabel, { color: readiness.color }]}>{readiness.label}</Text>
            <Text style={styles.readinessEn}>{readiness.labelEn}</Text>
          </View>
          <View style={[styles.gamingModeBadge, { backgroundColor: readiness.color + "22", borderColor: readiness.color + "66" }]}>
            <Text style={[styles.gamingModeText, { color: readiness.color }]}>Gaming Mode ⚡</Text>
          </View>
        </View>

        {/* Device name prominent */}
        <View style={styles.deviceCard}>
          <LinearGradient colors={["#00ccff0d", "#7b2fff08"]} style={styles.deviceGrad}>
            <MaterialCommunityIcons name="cellphone" size={36} color="#00ccff" />
            <Text style={styles.deviceManufacturer}>{manufacturer.toUpperCase()}</Text>
            <Text style={styles.deviceModel}>{modelName}</Text>
            <Text style={styles.deviceOs}>
              {Platform.OS === "android" ? "Android" : Platform.OS === "ios" ? "iOS" : "Web"} {osVersion}
            </Text>
          </LinearGradient>
        </View>

        {/* Spec rows */}
        {specs.map((spec, i) => (
          <View key={i} style={[styles.row, spec.highlight && styles.rowHighlight]}>
            <MaterialCommunityIcons name={spec.icon} size={20} color={spec.iconColor} style={styles.rowIcon} />
            <View style={styles.rowText}>
              <Text style={styles.rowLabelAr}>{spec.labelAr}</Text>
              <Text style={styles.rowLabelEn}>{spec.labelEn}</Text>
            </View>
            <Text style={[styles.rowValue, spec.highlight && { color: "#fff", fontWeight: "bold" }]}>
              {spec.value}
            </Text>
          </View>
        ))}

        {/* RAM split bar */}
        {totalRam && (
          <View style={styles.ramBarCard}>
            <Text style={styles.ramBarTitle}>استهلاك الذاكرة</Text>
            <View style={styles.ramTrack}>
              <View style={[styles.ramUsed, { flex: Math.round((1 - simAvailRam / totalRam) * 100) }]} />
              <View style={[styles.ramFree, { flex: Math.round((simAvailRam / totalRam) * 100) }]} />
            </View>
            <View style={styles.ramLegendRow}>
              <View style={styles.legendItem}>
                <View style={[styles.legendDot, { backgroundColor: "#ff4466" }]} />
                <Text style={styles.legendText}>مُستخدم: {bytesToGB(totalRam - simAvailRam)}</Text>
              </View>
              <View style={styles.legendItem}>
                <View style={[styles.legendDot, { backgroundColor: "#00ff88" }]} />
                <Text style={styles.legendText}>متاح: {bytesToGB(simAvailRam)}</Text>
              </View>
            </View>
          </View>
        )}

        <View style={{ height: 110 }} />
      </ScrollView>

      <AdBanner />
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1 },
  scroll: { paddingHorizontal: 20, paddingTop: 58 },
  header: { alignItems: "center", paddingVertical: 22, marginBottom: 14, borderRadius: 16 },
  title: { color: "#fff", fontSize: 26, fontWeight: "bold" },
  subtitle: { color: "#7b2fff", fontSize: 11, letterSpacing: 4, marginTop: 3, opacity: 0.8 },

  readinessBanner: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: "#12121c",
    borderWidth: 1,
    borderRadius: 12,
    padding: 14,
    marginBottom: 14,
    gap: 12,
  },
  readinessLabel: { fontSize: 15, fontWeight: "bold" },
  readinessEn: { color: "#6b7494", fontSize: 11, marginTop: 1 },
  gamingModeBadge: {
    borderWidth: 1,
    borderRadius: 8,
    paddingHorizontal: 8,
    paddingVertical: 4,
  },
  gamingModeText: { fontSize: 11, fontWeight: "bold" },

  deviceCard: { borderRadius: 16, overflow: "hidden", marginBottom: 14 },
  deviceGrad: { alignItems: "center", paddingVertical: 24, gap: 4 },
  deviceManufacturer: { color: "#6b7494", fontSize: 12, letterSpacing: 3, marginTop: 6 },
  deviceModel: { color: "#fff", fontSize: 22, fontWeight: "bold", textAlign: "center", paddingHorizontal: 16 },
  deviceOs: { color: "#00ccff", fontSize: 13, marginTop: 4 },

  row: {
    backgroundColor: "#12121c",
    flexDirection: "row",
    alignItems: "center",
    padding: 14,
    borderRadius: 12,
    marginBottom: 8,
    borderWidth: 1,
    borderColor: "#1e1e30",
  },
  rowHighlight: { borderColor: "#00ccff30" },
  rowIcon: { marginRight: 12, width: 24 },
  rowText: { flex: 1 },
  rowLabelAr: { color: "#fff", fontSize: 14, fontWeight: "500" },
  rowLabelEn: { color: "#6b7494", fontSize: 11, marginTop: 1 },
  rowValue: { color: "#00ccff", fontSize: 13, textAlign: "right", maxWidth: 140 },

  ramBarCard: {
    backgroundColor: "#12121c",
    borderRadius: 14,
    padding: 16,
    marginTop: 4,
    borderWidth: 1,
    borderColor: "#1e1e30",
  },
  ramBarTitle: { color: "#fff", fontSize: 14, fontWeight: "600", marginBottom: 12 },
  ramTrack: { flexDirection: "row", height: 8, borderRadius: 4, overflow: "hidden" },
  ramUsed: { backgroundColor: "#ff4466" },
  ramFree: { backgroundColor: "#00ff88" },
  ramLegendRow: { flexDirection: "row", justifyContent: "space-between", marginTop: 10 },
  legendItem: { flexDirection: "row", alignItems: "center", gap: 6 },
  legendDot: { width: 8, height: 8, borderRadius: 4 },
  legendText: { color: "#6b7494", fontSize: 12 },
});
