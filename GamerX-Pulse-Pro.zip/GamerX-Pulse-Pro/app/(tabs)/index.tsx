import React, { useState, useEffect, useRef } from "react";
import {
  StyleSheet,
  Text,
  View,
  TouchableOpacity,
  ScrollView,
  Animated,
} from "react-native";
import Svg, { Circle } from "react-native-svg";
import { LinearGradient } from "expo-linear-gradient";
import { Feather, MaterialCommunityIcons } from "@expo/vector-icons";
import AdBanner, { initAds } from "@/components/AdBanner";
import { useColors } from "@/hooks/useColors";

const RADIUS = 72;
const STROKE = 10;
const CIRC = 2 * Math.PI * RADIUS;
const CENTER = RADIUS + STROKE;

function useFluctuating(base: number, range: number, ms: number) {
  const [val, setVal] = useState(base);
  useEffect(() => {
    const id = setInterval(
      () => setVal(Math.min(99, Math.max(5, Math.round(base + (Math.random() - 0.5) * 2 * range)))),
      ms
    );
    return () => clearInterval(id);
  }, [base, range, ms]);
  return val;
}

type Stage = "idle" | "s1" | "s2" | "s3" | "done";

const STAGE_TEXT: Record<Stage, string> = {
  idle: "الجهاز مستقر وجاهز للعب 🟢",
  s1:   "جاري مسح الذاكرة المؤقتة... 🧹",
  s2:   "توجيه طاقة المعالج نحو الألعاب... 🔥",
  s3:   "تحرير الذاكرة العشوائية... ⚡",
  done: "",
};
const STAGE_PROG: Record<Stage, number> = { idle: 0, s1: 0.33, s2: 0.66, s3: 0.9, done: 1 };
const STAGE_NAMES = ["مسح Cache", "تحسين CPU", "تحرير RAM"];

export default function PerformanceScreen() {
  const colors = useColors();
  const rawRam = useFluctuating(57, 8, 2000);
  const rawCpu = useFluctuating(32, 18, 2000);

  const [stage, setStage] = useState<Stage>("idle");
  const [displayRam, setDisplayRam] = useState(57);
  const [freedMB, setFreedMB] = useState(0);

  const progress = useRef(new Animated.Value(0)).current;
  const pulse = useRef(new Animated.Value(1)).current;
  const glow = useRef(new Animated.Value(0)).current;
  const pulseLoop = useRef<ReturnType<typeof Animated.loop> | null>(null);
  const glowLoop = useRef<ReturnType<typeof Animated.loop> | null>(null);

  useEffect(() => { initAds(); }, []);

  useEffect(() => {
    if (stage === "idle" || stage === "done") setDisplayRam(rawRam);
  }, [rawRam, stage]);

  const animProg = (to: number, dur: number) =>
    Animated.timing(progress, { toValue: to, duration: dur, useNativeDriver: false }).start();

  const startLoops = () => {
    pulseLoop.current = Animated.loop(
      Animated.sequence([
        Animated.timing(pulse, { toValue: 1.07, duration: 500, useNativeDriver: false }),
        Animated.timing(pulse, { toValue: 1, duration: 500, useNativeDriver: false }),
      ])
    );
    pulseLoop.current.start();
    glowLoop.current = Animated.loop(
      Animated.sequence([
        Animated.timing(glow, { toValue: 1, duration: 700, useNativeDriver: false }),
        Animated.timing(glow, { toValue: 0.3, duration: 700, useNativeDriver: false }),
      ])
    );
    glowLoop.current.start();
  };

  const stopLoops = () => {
    pulseLoop.current?.stop();
    glowLoop.current?.stop();
    Animated.timing(pulse, { toValue: 1, duration: 200, useNativeDriver: false }).start();
    Animated.timing(glow, { toValue: 0, duration: 200, useNativeDriver: false }).start();
  };

  const handleBoost = () => {
    if (stage !== "idle" && stage !== "done") return;
    progress.setValue(0);
    startLoops();

    setStage("s1"); animProg(STAGE_PROG.s1, 500);
    setTimeout(() => { setStage("s2"); animProg(STAGE_PROG.s2, 500); }, 1800);
    setTimeout(() => { setStage("s3"); animProg(STAGE_PROG.s3, 500); }, 3600);
    setTimeout(() => {
      const freed = Math.floor(Math.random() * 430) + 370;
      setFreedMB(freed);
      setDisplayRam((p) => Math.max(18, p - 15));
      setStage("done");
      animProg(1, 400);
      stopLoops();
    }, 5200);
  };

  const isBoosting = stage === "s1" || stage === "s2" || stage === "s3";

  const ramOffset = CIRC * (1 - displayRam / 100);
  const cpuOffset = CIRC * (1 - rawCpu / 100);
  const ramColor = displayRam > 80 ? "#ff1a4b" : displayRam > 65 ? "#ffaa00" : "#00ccff";
  const cpuColor = rawCpu > 75 ? "#ff1a4b" : rawCpu > 55 ? "#ffaa00" : "#00ff88";

  const progressW = progress.interpolate({ inputRange: [0, 1], outputRange: ["0%", "100%"] });
  const glowOp = glow.interpolate({ inputRange: [0, 1], outputRange: [0.5, 1] });

  const activeStageIndex = stage === "s1" ? 0 : stage === "s2" ? 1 : stage === "s3" ? 2 : -1;

  return (
    <View style={[styles.root, { backgroundColor: colors.background }]}>
      <ScrollView contentContainerStyle={styles.scroll} showsVerticalScrollIndicator={false}>

        {/* Header */}
        <LinearGradient colors={["#00ccff1a", "#0a0a0f00"]} style={styles.header}>
          <Text style={styles.title}>مراقب الأداء</Text>
          <Text style={styles.subtitle}>PERFORMANCE MONITOR</Text>
        </LinearGradient>

        {/* Gauges */}
        <View style={styles.gaugesRow}>
          {/* RAM */}
          <View style={styles.gaugeWrap}>
            <Svg width={CENTER * 2} height={CENTER * 2}>
              <Circle cx={CENTER} cy={CENTER} r={RADIUS} stroke="#1e1e30" strokeWidth={STROKE} fill="none" />
              <Circle
                cx={CENTER} cy={CENTER} r={RADIUS}
                stroke={ramColor} strokeWidth={STROKE} fill="none"
                strokeDasharray={CIRC} strokeDashoffset={ramOffset}
                strokeLinecap="round"
                rotation="-90" originX={CENTER} originY={CENTER}
              />
            </Svg>
            <View style={styles.gaugeInner}>
              <Text style={[styles.gaugeVal, { color: ramColor }]}>{displayRam}%</Text>
              <Text style={styles.gaugeTag}>RAM</Text>
            </View>
            <Text style={[styles.gaugeName, { color: ramColor }]}>الذاكرة العشوائية</Text>
          </View>

          {/* CPU */}
          <View style={styles.gaugeWrap}>
            <Svg width={CENTER * 2} height={CENTER * 2}>
              <Circle cx={CENTER} cy={CENTER} r={RADIUS} stroke="#1e1e30" strokeWidth={STROKE} fill="none" />
              <Circle
                cx={CENTER} cy={CENTER} r={RADIUS}
                stroke={cpuColor} strokeWidth={STROKE} fill="none"
                strokeDasharray={CIRC} strokeDashoffset={cpuOffset}
                strokeLinecap="round"
                rotation="-90" originX={CENTER} originY={CENTER}
              />
            </Svg>
            <View style={styles.gaugeInner}>
              <Text style={[styles.gaugeVal, { color: cpuColor }]}>{rawCpu}%</Text>
              <Text style={styles.gaugeTag}>CPU</Text>
            </View>
            <Text style={[styles.gaugeName, { color: cpuColor }]}>المعالج</Text>
          </View>
        </View>

        {/* Live indicator */}
        <View style={styles.liveRow}>
          <View style={styles.liveDot} />
          <Text style={styles.liveText}>مباشر · يتحدث كل 2 ثانية</Text>
        </View>

        {/* Status card */}
        <View style={[styles.card, {
          borderColor: isBoosting ? "#ffaa00" : stage === "done" ? "#00ff88" : "#1e1e30"
        }]}>
          {stage === "done" ? (
            <View style={styles.successRow}>
              <MaterialCommunityIcons name="check-circle" size={20} color="#00ff88" />
              <Text style={styles.successText}>
                تم التسريع! تم تحرير{" "}
                <Text style={{ color: "#00ccff", fontWeight: "bold" }}>{freedMB} MB</Text>
                {" "}وضمان أعلى FPS لـ GamerX 🎮
              </Text>
            </View>
          ) : (
            <Text style={[styles.statusText, { color: isBoosting ? "#ffaa00" : "#00ff88" }]}>
              {STAGE_TEXT[stage]}
            </Text>
          )}

          {stage !== "idle" && (
            <>
              <View style={styles.progTrack}>
                <Animated.View style={[styles.progFill, {
                  width: progressW,
                  backgroundColor: stage === "done" ? "#00ff88" : "#ffaa00",
                }]} />
              </View>
              {isBoosting && (
                <View style={styles.stagesRow}>
                  {STAGE_NAMES.map((name, i) => (
                    <View key={i} style={styles.stageItem}>
                      <View style={[styles.stageDot, {
                        backgroundColor: i <= activeStageIndex ? "#ffaa00" : "#1e1e30"
                      }]} />
                      <Text style={styles.stageLbl}>{name}</Text>
                    </View>
                  ))}
                </View>
              )}
            </>
          )}
        </View>

        {/* Boost Button */}
        <Animated.View style={{ transform: [{ scale: pulse }] }}>
          <TouchableOpacity onPress={handleBoost} disabled={isBoosting} activeOpacity={0.85}>
            <Animated.View style={[styles.boostShadow, { opacity: isBoosting ? glowOp : 1 }]}>
              <LinearGradient
                colors={isBoosting
                  ? ["#5a001a", "#3a0010"]
                  : stage === "done"
                  ? ["#003a15", "#001a08"]
                  : ["#cc0030", "#ff1a4b", "#ff4400"]}
                start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }}
                style={styles.boostGrad}
              >
                <Feather
                  name={isBoosting ? "loader" : stage === "done" ? "check" : "zap"}
                  size={28} color="#fff"
                />
                <Text style={styles.boostLabel}>
                  {isBoosting ? "جاري التسريع..." : stage === "done" ? "إعادة التسريع ↺" : "🚀  SUPER BOOST"}
                </Text>
                {!isBoosting && (
                  <Text style={styles.boostHint}>
                    {stage === "done" ? "اضغط لإعادة التحسين" : "اضغط لتحسين أداء الألعاب"}
                  </Text>
                )}
              </LinearGradient>
            </Animated.View>
          </TouchableOpacity>
        </Animated.View>

        <View style={{ height: 110 }} />
      </ScrollView>

      <AdBanner />
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1 },
  scroll: { paddingHorizontal: 20, paddingTop: 58 },
  header: { alignItems: "center", paddingVertical: 22, marginBottom: 8, borderRadius: 16 },
  title: { color: "#fff", fontSize: 26, fontWeight: "bold", letterSpacing: 0.5 },
  subtitle: { color: "#00ccff", fontSize: 11, letterSpacing: 4, marginTop: 3, opacity: 0.8 },

  gaugesRow: { flexDirection: "row", justifyContent: "space-evenly", marginVertical: 10 },
  gaugeWrap: { alignItems: "center" },
  gaugeInner: {
    position: "absolute",
    top: 0, left: 0, right: 0,
    bottom: 26,
    alignItems: "center", justifyContent: "center",
  },
  gaugeVal: { fontSize: 28, fontWeight: "bold", letterSpacing: -1 },
  gaugeTag: { color: "#6b7494", fontSize: 10, letterSpacing: 2, marginTop: 2 },
  gaugeName: { fontSize: 12, fontWeight: "600", marginTop: 4 },

  liveRow: { flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 7, marginBottom: 14 },
  liveDot: { width: 7, height: 7, borderRadius: 4, backgroundColor: "#00ff88" },
  liveText: { color: "#6b7494", fontSize: 12 },

  card: {
    backgroundColor: "#12121c",
    borderWidth: 1,
    borderRadius: 14,
    padding: 16,
    minHeight: 58,
    justifyContent: "center",
    marginBottom: 20,
  },
  statusText: { fontSize: 15, textAlign: "center", fontWeight: "500" },
  successRow: { flexDirection: "row", alignItems: "flex-start", gap: 10 },
  successText: { color: "#fff", fontSize: 14, flex: 1, lineHeight: 21 },

  progTrack: { height: 4, backgroundColor: "#1e1e30", borderRadius: 2, marginTop: 14, overflow: "hidden" },
  progFill: { height: "100%", borderRadius: 2 },
  stagesRow: { flexDirection: "row", justifyContent: "space-around", marginTop: 10 },
  stageItem: { alignItems: "center", gap: 5 },
  stageDot: { width: 8, height: 8, borderRadius: 4 },
  stageLbl: { color: "#6b7494", fontSize: 10 },

  boostShadow: {
    borderRadius: 18,
    overflow: "hidden",
    shadowColor: "#ff1a4b",
    shadowOffset: { width: 0, height: 8 },
    shadowOpacity: 0.55,
    shadowRadius: 18,
    elevation: 14,
  },
  boostGrad: { alignItems: "center", paddingVertical: 24, paddingHorizontal: 32, gap: 6 },
  boostLabel: { color: "#fff", fontSize: 22, fontWeight: "bold", letterSpacing: 1 },
  boostHint: { color: "rgba(255,255,255,0.55)", fontSize: 12 },
});
